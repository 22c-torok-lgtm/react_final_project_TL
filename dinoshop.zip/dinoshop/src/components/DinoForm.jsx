import { useRef } from "react";

const DinoForm = () => {
    return(
        <>
        <h1>DinoForm</h1>
        </>
    )
}

export default DinoForm;